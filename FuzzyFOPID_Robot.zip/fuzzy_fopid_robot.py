import time
import numpy as np
import RPi.GPIO as GPIO
from mpu6050 import mpu6050
import skfuzzy as fuzz
from skfuzzy import control as ctrl

IN1, IN2, ENA = 4, 17, 18
IN3, IN4, ENB = 27, 22, 23
GPIO.setmode(GPIO.BCM)
GPIO.setup([IN1, IN2, ENA, IN3, IN4, ENB], GPIO.OUT)
pwmA = GPIO.PWM(ENA, 1000)
pwmB = GPIO.PWM(ENB, 1000)
pwmA.start(0)
pwmB.start(0)

def set_motors(speed):
    speed = max(min(speed, 100), -100)
    direction = GPIO.HIGH if speed >= 0 else GPIO.LOW
    GPIO.output(IN1, direction)
    GPIO.output(IN2, not direction)
    GPIO.output(IN3, direction)
    GPIO.output(IN4, not direction)
    pwmA.ChangeDutyCycle(abs(speed))
    pwmB.ChangeDutyCycle(abs(speed))

sensor = mpu6050(0x68)

def get_pitch():
    accel = sensor.get_accel_data()
    pitch = np.arctan2(accel['x'], accel['z']) * 180 / np.pi
    return pitch + 180

error = ctrl.Antecedent(np.arange(-30, 30.1, 0.1), 'error')
d_error = ctrl.Antecedent(np.arange(-10, 10.1, 0.1), 'd_error')
kp = ctrl.Consequent(np.arange(0, 100.1, 1), 'kp')
ki = ctrl.Consequent(np.arange(0, 100.1, 1), 'ki')
kd = ctrl.Consequent(np.arange(0, 10.1, 0.1), 'kd')

error.automf(names=['NB', 'NS', 'Z', 'PS', 'PB'])
d_error.automf(names=['NB', 'NS', 'Z', 'PS', 'PB'])

for out in [kp, ki, kd]:
    out['NB'] = fuzz.trimf(out.universe, [0, 0, 25])
    out['NS'] = fuzz.trimf(out.universe, [15, 30, 45])
    out['Z']  = fuzz.trimf(out.universe, [40, 50, 60])
    out['PS'] = fuzz.trimf(out.universe, [55, 70, 85])
    out['PB'] = fuzz.trimf(out.universe, [75, 100, 100])

rules = [
    ctrl.Rule(error['NB'] & d_error['NB'], (kp['PB'], ki['NB'], kd['NB'])),
    ctrl.Rule(error['NB'] & d_error['Z'],  (kp['PB'], ki['NS'], kd['NS'])),
    ctrl.Rule(error['NB'] & d_error['PB'], (kp['PB'], ki['Z'],  kd['Z'])),
    ctrl.Rule(error['Z']  & d_error['NB'], (kp['PS'], ki['NS'], kd['PB'])),
    ctrl.Rule(error['Z']  & d_error['Z'],  (kp['Z'],  ki['Z'],  kd['Z'])),
    ctrl.Rule(error['Z']  & d_error['PB'], (kp['NS'], ki['PS'], kd['NB'])),
    ctrl.Rule(error['PB'] & d_error['NB'], (kp['NB'], ki['Z'],  kd['PB'])),
    ctrl.Rule(error['PB'] & d_error['Z'],  (kp['NB'], ki['NS'], kd['NS'])),
    ctrl.Rule(error['PB'] & d_error['PB'], (kp['NB'], ki['NB'], kd['NB'])),
]

control_system = ctrl.ControlSystem(rules)
fuzzy_controller = ctrl.ControlSystemSimulation(control_system)

setpoint = 172.5
eold, eold2, eold3 = 0, 0, 0
uk, ukold = 0, 0

try:
    while True:
        input_angle = get_pitch()
        e = setpoint - input_angle
        de = e - eold

        fuzzy_controller.input['error'] = e
        fuzzy_controller.input['d_error'] = de
        fuzzy_controller.compute()

        Kp = fuzzy_controller.output['kp']
        Ki = fuzzy_controller.output['ki']
        Kd = fuzzy_controller.output['kd']

        uk = ukold + Kp*(e - eold) + Ki*(e + eold) +              (-2*(1-0.9)*(eold + eold2)) + (2 * pow(1 - 0.9, 2) * (eold2 + eold3)) +              Kd*((e - eold) + (-2 * 0.9 * (eold - eold2)) + 2 * pow(0.9, 2) * (eold2 - eold3))

        eold3, eold2, eold = eold2, eold, e
        ukold = uk

        uk = max(min(uk, 100), -100)
        set_motors(uk)

        print(f"Input: {input_angle:.2f}, Error: {e:.2f}, Output: {uk:.2f}")
        time.sleep(0.01)

except KeyboardInterrupt:
    pwmA.stop()
    pwmB.stop()
    GPIO.cleanup()
